import xbmcgui
import xbmc
from tmdb import TMDB
from utils import log

class SeasonEpisodeDialog:
    def __init__(self):
        self.tmdb = TMDB()
        self.season_cache = {}
        self.episode_cache = {}
    
    def select_season(self, tmdb_id, series_title):
        cache_key = f"series_{tmdb_id}"
        
        if cache_key in self.season_cache:
            season_data = self.season_cache[cache_key]
        else:
            series_details = self.tmdb.get_tv_details(tmdb_id)
            if not series_details:
                xbmcgui.Dialog().ok('Error', 'No se pudo obtener información de la serie.')
                return None
            
            num_seasons = series_details.get('number_of_seasons', 0)
            season_data = []
            
            if num_seasons > 0:
                for season_num in range(1, num_seasons + 1):
                    season_info = self.tmdb._make_request(f'tv/{tmdb_id}/season/{season_num}', {
                        'language': self.tmdb.language
                    })
                    
                    if season_info:
                        season_name = season_info.get('name', f'Temporada {season_num}')
                        episode_count = len(season_info.get('episodes', []))
                        air_date = season_info.get('air_date', '')
                        year = air_date[:4] if air_date else ''
                        
                        season_data.append({
                            'season_number': season_num,
                            'name': season_name,
                            'episode_count': episode_count,
                            'year': year
                        })
            
            self.season_cache[cache_key] = season_data
        
        if not season_data:
            xbmcgui.Dialog().ok('Información', 'No se encontraron temporadas para esta serie.')
            return None
        
        season_items = []
        for season in season_data:
            label = f"[B]{season['name']}[/B]"
            if season['year']:
                label += f" ({season['year']})"
            if season['episode_count'] > 0:
                label += f" - {season['episode_count']} episodios"
            season_items.append(label)
        
        dialog = xbmcgui.Dialog()
        selected_index = dialog.select(f'Seleccionar Temporada - {series_title}', season_items)
        
        if selected_index >= 0:
            return season_data[selected_index]
        
        return None
    
    def select_episode(self, tmdb_id, series_title, season_number):
        cache_key = f"series_{tmdb_id}_season_{season_number}"
        
        if cache_key in self.episode_cache:
            episode_data = self.episode_cache[cache_key]
        else:
            season_info = self.tmdb._make_request(f'tv/{tmdb_id}/season/{season_number}', {
                'language': self.tmdb.language,
                'append_to_response': 'credits,images'
            })
            
            if not season_info or 'episodes' not in season_info:
                xbmcgui.Dialog().ok('Error', 'No se pudo obtener información de los episodios.')
                return None
            
            episodes = season_info.get('episodes', [])
            episode_data = []
            
            for episode in episodes:
                episode_num = episode.get('episode_number', 0)
                episode_name = episode.get('name', f'Episodio {episode_num}')
                air_date = episode.get('air_date', '')
                overview = episode.get('overview', '')
                
                date_display = ''
                if air_date:
                    try:
                        parts = air_date.split('-')
                        if len(parts) == 3:
                            date_display = f"{parts[2]}/{parts[1]}/{parts[0]}"
                    except:
                        date_display = air_date
                
                episode_data.append({
                    'episode_number': episode_num,
                    'name': episode_name,
                    'air_date': air_date,
                    'overview': overview,
                    'episode_title': episode_name
                })
            
            self.episode_cache[cache_key] = episode_data
        
        if not episode_data:
            xbmcgui.Dialog().ok('Información', 'No se encontraron episodios para esta temporada.')
            return None
        
        episode_items = []
        for episode in episode_data:
            episode_num = episode['episode_number']
            episode_name = episode['name']
            date_display = ''
            
            if episode['air_date']:
                try:
                    parts = episode['air_date'].split('-')
                    if len(parts) == 3:
                        date_display = f"{parts[2]}/{parts[1]}/{parts[0]}"
                except:
                    date_display = episode['air_date']
            
            label = f"Episodio {episode_num}: {episode_name}"
            if date_display:
                label += f" ({date_display})"
            
            if episode['overview']:
                short_overview = episode['overview'][:60] + "..." if len(episode['overview']) > 60 else episode['overview']
                label += f" - {short_overview}"
            
            episode_items.append(label)
        
        dialog = xbmcgui.Dialog()
        selected_index = dialog.select(
            f'Seleccionar Episodio - {series_title} (Temporada {season_number})', 
            episode_items
        )
        
        if selected_index >= 0:
            return episode_data[selected_index]
        
        return None