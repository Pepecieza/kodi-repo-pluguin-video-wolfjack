import urllib.parse
import json

class JacktookPlayer:
    def __init__(self):
        self.base_plugin_url = "plugin://plugin.video.jacktook/"
    
    def get_movie_play_url(self, title, tmdb_id='', tvdb_id='', imdb_id=''):
        """Generar URL para reproducir película - Formato Tmdb Helper"""
        # Codificar título para URL
        encoded_title = urllib.parse.quote_plus(title)
        
        # Construir URL exacta como Tmdb Helper
        url = f"{self.base_plugin_url}?action=search&mode=movies&rescrape=True&query={encoded_title}"
        return url
    
    def get_series_play_url(self, showname, tmdb_id='', tvdb_id='', imdb_id='', season=1, episode=1, episode_title=''):
        """Generar URL para reproducir episodio de serie - Formato Tmdb Helper"""
        # Si no hay título del episodio, usar el de la serie
        if not episode_title:
            episode_title = showname
        
        # Codificar parámetros
        encoded_showname = urllib.parse.quote_plus(showname)
        encoded_episode_title = urllib.parse.quote_plus(episode_title)
        
        # Crear tv_data JSON (EXACTAMENTE como Tmdb Helper)
        tv_data = {
            "name": episode_title,
            "episode": str(episode),
            "season": str(season)
        }
        # Codificar JSON para URL
        tv_data_json = json.dumps(tv_data, separators=(', ', ': '))
        encoded_tv_data = urllib.parse.quote_plus(tv_data_json)
        
        # Construir URL exacta como Tmdb Helper
        url = (f"{self.base_plugin_url}?action=search&mode=tv&rescrape=True"
               f"&query={encoded_showname}&tv_data={encoded_tv_data}")
        
        return url