import xbmcaddon
import xbmc
import requests
import json
import time
import re
from utils import log

class TMDB:
    def __init__(self):
        addon = xbmcaddon.Addon()
        self.API_KEY = addon.getSetting('tmdb_api_key') or 'c8b7db701bac0b26edfcc93b39858972'
        self.BASE_URL = "https://api.themoviedb.org/3"
        self.language = xbmc.getLanguage(xbmc.ISO_639_1) or 'es'
        self.timeout = 10
        self.cache = {}
        self.cache_timeout = 300
        self.last_request_time = 0
        self.request_interval = 0.35
        
        # Configurar sesión DIRECTA (sin proxy)
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
        })
        
        self.year_regex = re.compile(r'\((\d{4})\)$')
        self.clean_regex = re.compile(r'\s*\[.*?\]\s*')
        
        self.COMMON_TYPO_CORRECTIONS = {
            "Strangers Capitulo 2 (2025)": "Strangers: Capítulo 2 (2025)",
            "Strangers Capitulo 2": "Strangers: Capítulo 2",
            "Strangers  Capitulo 2": "Strangers: Capítulo 2",
            "Fritos a balazos (2025)": "Fritos a balazos (2025)",
            "Fritos a balazos": "Fritos a balazos",
            "Inheritance (2025)": "La herencia (2025)",
            "Inheritance": "La herencia",
            "Eden": "Edén",
            "Solo para mi (2026)": "Solo para mi (2024)",
            "Solo para mi (2024)": "Solo para mi (2024)",
            "Solo para mi": "Solo para mi",
            "El quarterback y yo (2024)": "El quarterback y yo (2025)",
            "El quarterback y yo (2025)": "El quarterback y yo (2025)",
            "El quarterback y yo": "El quarterback y yo",
            "Un mundo maravilloso (2026)": "Un mundo maravilloso (2025)",
            "Un mundo maravilloso (2025)": "Un mundo maravilloso (2025)",
            "Un mundo maravilloso": "Un mundo maravilloso",
            "Los lazos que nos unen (2026)": "Los lazos que nos unen (2025)",
            "Los lazos que nos unen (2025)": "Los lazos que nos unen (2025)",
            "Los lazos que nos unen": "Los lazos que nos unen",
            "Baltimore (2023)": "Baltimore (2024)",
            "Baltimore (2024)": "Baltimore (2024)",
            "Baltimore": "Baltimore",
            "Ruido (2025)": "Ruido (2024)",
            "Ruido (2024)": "Ruido (2024)",
            "Ruido": "Ruido",
            "Vera (2023)": "Vera (2023)",
            "Vera (2011)": "Vera (2023)",
            "Vera": "Vera (2023)",
            "Ru": "Ru",
            "Mothers' Instinct": "El instinto materno",
            "Mothers Instinct": "El instinto materno",
            "El instinto materno (2024)": "El instinto materno (2024)",
            "El instinto materno": "El instinto materno",
            "Juegos de ninos (Playdate)": "Juegos de niños (Playdate)",
            "ninos": "niños",
            "Juegos de ninos": "Juegos de niños",
            "La mitad perdida (Twinless)": "Mi mitad perdida (Twinless)",
            "Mythic Quest Mas alla el juego": "Mythic Quest: Más allá del juego",
            "Little Bird los nimos robados": "Little Bird, los niños robados",
            "nimos": "niños",
            "Sobrevivir al cartel": "Sobreviviendo al cártel",
            "Cara a cara el capitulo final": "Cara a cara (Forhøret)",
            "Alien Earth": "Alien: Planeta Tierra (Alien: Earth)",
            "Alien Earth": "Alien: Planeta Tierra",
            "El instituto": "El Instituto (The Institute)",
            "El instituto": "The Institute",
            "El magnate": "El magnate (Stenbeck)",
            "El magnate": "Stenbeck",
            "66th N0rth Precinct": "Puños de hielo",
            "66th NOrth Precinct": "Puños de hielo",
            "Wolf Hall El Trueno en el reino": "Wolf Hall"
        }
        
        self.ALTERNATIVE_TITLES = {
            "Strangers: Capítulo 2": ["The Strangers: Chapter 2", "Strangers Chapter 2", "Strangers Capitulo 2"],
            "Fritos a balazos": ["Guns Up", "Guns Up!"],
            "La herencia": ["Inheritance"],
            "El quarterback y yo": ["Sidelined: The QB and Me", "Sidelined", "The QB and Me"],
            "El instinto materno": ["Mothers' Instinct", "Mothers Instinct"]
        }
        
        self.YEAR_CORRECTIONS = {
            "Baltimore": {"2023": "2024"},
            "Solo para mi": {"2026": "2024"},
            "El quarterback y yo": {"2024": "2025"},
            "Un mundo maravilloso": {"2026": "2025"},
            "Los lazos que nos unen": {"2026": "2025"},
            "Ruido": {"2025": "2024"}
        }

    def _normalize_title(self, title):
        if not title:
            return ''
        normalized = re.sub(r'\s*\(\d{4}\)\s*$', '', title)
        normalized = self.clean_regex.sub(' ', normalized)
        normalized = re.sub(r'\s+(4K|HDR|UHD|DUAL|ESP|LAT|SUB|AC3|5\.1|1080p|720p|WEB|Bluray).*', '', normalized, flags=re.I)
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        return normalized

    def _extract_title_and_year(self, title):
        year_match = self.year_regex.search(title)
        if year_match:
            year = year_match.group(1)
            clean_title = re.sub(r'\s*\(\d{4}\)$', '', title).strip()
            return clean_title, year
        return title, None

    def _correct_common_typos(self, title):
        if not title:
            return title
        
        clean_title, year = self._extract_title_and_year(title)
        
        for wrong_title, correct_title in self.COMMON_TYPO_CORRECTIONS.items():
            if title.lower() == wrong_title.lower():
                log(f"Corrigiendo título exacto: '{wrong_title}' -> '{correct_title}'")
                return correct_title
        
        for wrong_title, correct_title in self.COMMON_TYPO_CORRECTIONS.items():
            wrong_without_year = re.sub(r'\s*\(\d{4}\)\s*$', '', wrong_title).strip().lower()
            if clean_title.lower() == wrong_without_year.lower():
                if year and clean_title in self.YEAR_CORRECTIONS and year in self.YEAR_CORRECTIONS[clean_title]:
                    corrected_year = self.YEAR_CORRECTIONS[clean_title][year]
                    corrected = f"{clean_title} ({corrected_year})"
                    log(f"Corrigiendo año: '{title}' -> '{corrected}'")
                    return corrected
                else:
                    corrected = f"{clean_title} ({year})" if year else correct_title
                    log(f"Corrigiendo título sin año: '{title}' -> '{corrected}'")
                    return corrected
        
        if clean_title in self.YEAR_CORRECTIONS and year and year in self.YEAR_CORRECTIONS[clean_title]:
            corrected_year = self.YEAR_CORRECTIONS[clean_title][year]
            corrected = f"{clean_title} ({corrected_year})"
            log(f"Corrigiendo solo el año: '{title}' -> '{corrected}'")
            return corrected
        
        return title

    def _respect_rate_limit(self):
        elapsed = time.time() - self.last_request_time
        if elapsed < self.request_interval:
            time.sleep(self.request_interval - elapsed)
        self.last_request_time = time.time()

    def _make_request(self, endpoint, params=None):
        cache_key = f"{endpoint}_{json.dumps(params or {}, sort_keys=True)}"
        
        current_time = time.time()
        if cache_key in self.cache:
            cache_time, data = self.cache[cache_key]
            if current_time - cache_time < self.cache_timeout:
                return data
        
        self._respect_rate_limit()
        
        url = f"{self.BASE_URL}/{endpoint}"
        default_params = {
            'api_key': self.API_KEY,
            'language': self.language,
            'include_image_language': 'es,en'
        }
        if params:
            default_params.update(params)

        try:
            # Usar sesión DIRECTA (sin proxy) para TMDB
            response = self.session.get(url, params=default_params, timeout=self.timeout)
            if response.status_code == 200:
                data = response.json()
                self.cache[cache_key] = (current_time, data)
                return data
            elif response.status_code == 429:
                time.sleep(1)
                return self._make_request(endpoint, params)
        except requests.exceptions.Timeout:
            log(f"TMDB timeout: {endpoint}")
        except Exception as e:
            log(f"TMDB error {endpoint}: {str(e)[:100]}")
        
        return None

    def _find_best_match(self, results, search_title, search_year=None):
        if not results:
            return None
        
        search_variants, extracted_year = self._extract_title_and_year(search_title)
        search_variants = [search_variants]
        
        if not search_year and extracted_year:
            search_year = extracted_year
        
        norm_variants = [self._normalize_title(variant).lower() for variant in search_variants]
        
        for r in results:
            title = r.get('title') or r.get('name') or ''
            norm_title = self._normalize_title(title).lower()
            year = (r.get('release_date') or r.get('first_air_date') or '')[:4]
            
            for norm_variant in norm_variants:
                if norm_title == norm_variant and (not search_year or year == search_year):
                    return r

        for r in results:
            title = r.get('title') or r.get('name') or ''
            norm_title = self._normalize_title(title).lower()
            year = (r.get('release_date') or r.get('first_air_date') or '')[:4]
            
            for norm_variant in norm_variants:
                if (norm_variant in norm_title or norm_title in norm_variant) and (not search_year or year == search_year):
                    return r

        valid = [r for r in results if r.get('vote_count', 0) > 5]
        return valid[0] if valid else results[0] if results else None

    def search_movie(self, title, year=''):
        corrected_title = self._correct_common_typos(title)
        if corrected_title != title:
            log(f"Corrección en search_movie: '{title}' -> '{corrected_title}'")
            title = corrected_title
        
        clean_title, corrected_year = self._extract_title_and_year(title)
        
        if not year and corrected_year:
            year = corrected_year
        
        normalized = self._normalize_title(clean_title)
        log(f"TMDB movie search: '{normalized}' ({year})")

        params = {'query': normalized}
        if year and year.isdigit() and len(year) == 4:
            params['year'] = year

        data = self._make_request('search/movie', params)
        if data and data.get('results'):
            best = self._find_best_match(data['results'], normalized, year)
            if best:
                return self.get_movie_details(best['id'])

        if year:
            data = self._make_request('search/movie', {'query': normalized})
            if data and data.get('results'):
                best = self._find_best_match(data['results'], normalized)
                if best:
                    return self.get_movie_details(best['id'])
        
        if clean_title in self.ALTERNATIVE_TITLES:
            for alt_title in self.ALTERNATIVE_TITLES[clean_title]:
                log(f"Buscando con título alternativo: '{alt_title}'")
                params = {'query': alt_title}
                if year:
                    params['year'] = year
                
                data = self._make_request('search/movie', params)
                if data and data.get('results'):
                    best = self._find_best_match(data['results'], alt_title, year)
                    if best:
                        return self.get_movie_details(best['id'])
        
        return None

    def search_tv(self, title, year=''):
        corrected_title = self._correct_common_typos(title)
        if corrected_title != title:
            log(f"Corrección en search_tv: '{title}' -> '{corrected_title}'")
            title = corrected_title
        
        clean_title, corrected_year = self._extract_title_and_year(title)
        
        if not year and corrected_year:
            year = corrected_year
            
        normalized = self._normalize_title(clean_title)
        log(f"TMDB tv search: '{normalized}' ({year})")

        params = {'query': normalized}
        if year and year.isdigit() and len(year) == 4:
            params['first_air_date_year'] = year

        data = self._make_request('search/tv', params)
        if data and data.get('results'):
            best = self._find_best_match(data['results'], normalized, year)
            if best:
                return self.get_tv_details(best['id'])

        if year:
            data = self._make_request('search/tv', {'query': normalized})
            if data and data.get('results'):
                best = self._find_best_match(data['results'], normalized)
                if best:
                    return self.get_tv_details(best['id'])
        
        if clean_title in self.ALTERNATIVE_TITLES:
            for alt_title in self.ALTERNATIVE_TITLES[clean_title]:
                log(f"Buscando con título alternativo: '{alt_title}'")
                params = {'query': alt_title}
                if year:
                    params['first_air_date_year'] = year
                
                data = self._make_request('search/tv', params)
                if data and data.get('results'):
                    best = self._find_best_match(data['results'], alt_title, year)
                    if best:
                        return self.get_tv_details(best['id'])
        
        return None

    def multi_search(self, query):
        corrected_query = self._correct_common_typos(query)
        if corrected_query != query:
            log(f"Corrección en multi_search: '{query}' -> '{corrected_query}'")
            query = corrected_query
            
        normalized = self._normalize_title(query)
        data = self._make_request('search/multi', {'query': normalized})
        return data.get('results', [])[:20] if data else []

    def get_movie_details(self, movie_id):
        data = self._make_request(f'movie/{movie_id}', {
            'append_to_response': 'credits,release_dates,images,keywords',
            'include_image_language': 'es,en,null'
        })
        if not data:
            return None

        certification = ''
        for country in data.get('release_dates', {}).get('results', []):
            if country['iso_3166_1'] in ['ES', 'US', 'MX']:
                for rel in country['release_dates']:
                    if rel.get('certification'):
                        certification = rel['certification']
                        break
                break

        genres = [g['name'] for g in data.get('genres', [])]
        fanart = ''
        if data.get('images', {}).get('backdrops'):
            backdrops = sorted(
                [b for b in data['images']['backdrops'] if b.get('width', 0) > 500],
                key=lambda x: x.get('vote_average', 0),
                reverse=True
            )
            if backdrops:
                fanart = f"https://image.tmdb.org/t/p/original{backdrops[0]['file_path']}"

        return {
            'id': data['id'],
            'title': data['title'],
            'overview': data['overview'],
            'release_date': data['release_date'],
            'year': data['release_date'][:4] if data.get('release_date') else '',
            'vote_average': data['vote_average'],
            'poster_path': data.get('poster_path'),
            'backdrop_path': data.get('backdrop_path'),
            'fanart': fanart,
            'runtime': data['runtime'],
            'genres': genres,
            'certification': certification,
            'imdb_id': data.get('imdb_id')
        }

    def get_tv_details(self, tv_id):
        data = self._make_request(f'tv/{tv_id}', {
            'append_to_response': 'content_ratings,credits,images,keywords',
            'include_image_language': 'es,en,null'
        })
        if not data:
            return None

        certification = ''
        for country in data.get('content_ratings', {}).get('results', []):
            if country['iso_3166_1'] in ['ES', 'US', 'MX']:
                certification = country.get('rating', '')
                break

        genres = [g['name'] for g in data.get('genres', [])]
        fanart = ''
        if data.get('images', {}).get('backdrops'):
            backdrops = sorted(
                [b for b in data['images']['backdrops'] if b.get('width', 0) > 500],
                key=lambda x: x.get('vote_average', 0),
                reverse=True
            )
            if backdrops:
                fanart = f"https://image.tmdb.org/t/p/original{backdrops[0]['file_path']}"

        return {
            'id': data['id'],
            'name': data['name'],
            'overview': data['overview'],
            'first_air_date': data['first_air_date'],
            'year': data['first_air_date'][:4] if data.get('first_air_date') else '',
            'vote_average': data['vote_average'],
            'poster_path': data.get('poster_path'),
            'backdrop_path': data.get('backdrop_path'),
            'fanart': fanart,
            'number_of_seasons': data['number_of_seasons'],
            'genres': genres,
            'certification': certification
        }

    def get_tv_external_ids(self, tv_id):
        data = self._make_request(f'tv/{tv_id}/external_ids')
        if not data:
            return {}
        
        return {
            'tvdb_id': str(data.get('tvdb_id', '')) if data.get('tvdb_id') else '',
            'imdb_id': data.get('imdb_id', ''),
            'tvrage_id': data.get('tvrage_id', ''),
            'facebook_id': data.get('facebook_id', ''),
            'instagram_id': data.get('instagram_id', ''),
            'twitter_id': data.get('twitter_id', '')
        }
    
    def get_episode_details(self, tv_id, season, episode):
        data = self._make_request(f'tv/{tv_id}/season/{season}/episode/{episode}')
        if not data:
            return None
        
        return {
            'id': data.get('id'),
            'name': data.get('name'),
            'overview': data.get('overview'),
            'season_number': data.get('season_number'),
            'episode_number': data.get('episode_number'),
            'air_date': data.get('air_date'),
            'vote_average': data.get('vote_average'),
            'vote_count': data.get('vote_count'),
            'still_path': data.get('still_path')
        }