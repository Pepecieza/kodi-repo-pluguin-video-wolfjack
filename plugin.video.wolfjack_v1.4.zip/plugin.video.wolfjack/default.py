import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import os
import urllib.parse
import re
import requests

if 'resources.lib' not in sys.path:
    sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))

from scraper import WolfmaxScraper
from tmdb import TMDB
from player import JacktookPlayer
from dialogs import SeasonEpisodeDialog
from utils import log
from proxy_manager import ProxyManager
from disk_cache import DiskCacheManager

_addon = None
_addon_handle = None
_base_url = None
_scraper_instance = None
_tmdb_instance = None
_player_instance = None
_proxy_manager_instance = None
_cache_manager_instance = None

def get_addon():
    global _addon
    if _addon is None:
        _addon = xbmcaddon.Addon()
    return _addon

def get_scraper():
    global _scraper_instance
    if _scraper_instance is None:
        _scraper_instance = WolfmaxScraper()
    return _scraper_instance

def get_tmdb():
    global _tmdb_instance
    if _tmdb_instance is None:
        _tmdb_instance = TMDB()
    return _tmdb_instance

def get_player():
    global _player_instance
    if _player_instance is None:
        _player_instance = JacktookPlayer()
    return _player_instance

def get_proxy_manager():
    global _proxy_manager_instance
    if _proxy_manager_instance is None:
        _proxy_manager_instance = ProxyManager()
    return _proxy_manager_instance

def get_cache_manager():
    global _cache_manager_instance
    if _cache_manager_instance is None:
        _cache_manager_instance = DiskCacheManager()
    return _cache_manager_instance

addon = get_addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

BASE_URLS = {
    'movies_4k': 'https://wolfmax4k.com/peliculas/4k-2160p/',
    'movies_1080p': 'https://wolfmax4k.com/peliculas/bluray-1080p/',
    'movies_720p': 'https://wolfmax4k.com/peliculas/bluray-720p/',
    'movies_bluray': 'https://wolfmax4k.com/peliculas/bluray/',
    'series_4k': 'https://wolfmax4k.com/series/4k-2160p/',
    'series_1080p': 'https://wolfmax4k.com/series/1080p/',
    'series_720p': 'https://wolfmax4k.com/series/720p/',
    'series_480p': 'https://wolfmax4k.com/series/480p/'
}

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def clean_display_title(title, year):
    if not title:
        return title
    title = re.sub(r'\[.*?\]', '', title)
    title = re.sub(r'\b\w+\]', '', title)
    title = re.sub(r'\[|\]', '', title)
    title = re.sub(r'\s+', ' ', title).strip()
    return title

def test_wolfmax_connection():
    try:
        proxy_manager = get_proxy_manager()
        proxy_info = proxy_manager.get_proxy_info()
        if proxy_info['enabled']:
            session = proxy_manager.get_session_with_proxy()
        else:
            session = requests.Session()
            session.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
        response = session.get('https://wolfmax4k.com/', timeout=10)
        if response.status_code == 200:
            return True, 'Conexión con [COLOR lime]wolfmax4k.com[/COLOR] OK'
        return False, f'Status: {response.status_code}'
    except Exception as e:
        return False, f'Error: {str(e)}'

def main_menu():
    addon_path = addon.getAddonInfo('path')
    fanart_path = os.path.join(addon_path, 'fanart.jpg')
    proxy_manager = get_proxy_manager()
    proxy_info = proxy_manager.get_proxy_info()

    li = xbmcgui.ListItem(label='[B][COLOR FF00ACC1]## WOLFJACK by ManEthan ##[/COLOR][/B]')
    li.setArt({'thumb': 'DefaultMovies.png', 'icon': 'DefaultMovies.png', 'fanart': fanart_path})
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(addon_handle, 'plugin://plugin.video.wolfjack/?mode=noop', li, False)

    proxy_status = f"[B][COLOR lime]• Proxy Activo: {proxy_info['address']}[/COLOR][/B]" if proxy_info['enabled'] else "[B][COLOR red]• Proxy: Desactivado[/COLOR][/B]"
    li = xbmcgui.ListItem(label=proxy_status)
    li.setArt({'thumb': 'DefaultMovies.png', 'icon': 'DefaultMovies.png', 'fanart': fanart_path})
    xbmcplugin.addDirectoryItem(addon_handle, build_url({'mode': 'proxy_settings'}), li, False)

    li = xbmcgui.ListItem(label='[B][COLOR FFF06292]• Test web Wolfmax4k[/COLOR][/B]')
    li.setArt({'thumb': 'DefaultMovies.png', 'icon': 'DefaultMovies.png', 'fanart': fanart_path})
    xbmcplugin.addDirectoryItem(addon_handle, build_url({'mode': 'test_connection'}), li, False)

    items = [
        {'title': '[B][COLOR gold]• Películas 4K[/COLOR][/B]', 'mode': 'list_movies', 'type': 'movies_4k'},
        {'title': '[B][COLOR FFFFF9C4]• Películas Bluray 1080p[/COLOR][/B]', 'mode': 'list_movies', 'type': 'movies_1080p'},
        {'title': '[B][COLOR gold]• Películas Bluray 720p[/COLOR][/B]', 'mode': 'list_movies', 'type': 'movies_720p'},
        {'title': '[B][COLOR FFFFF9C4]• Películas Bluray[/COLOR][/B]', 'mode': 'list_movies', 'type': 'movies_bluray'},
        {'title': '[B][COLOR lime]• Series 4K[/COLOR][/B]', 'mode': 'list_series', 'type': 'series_4k'},
        {'title': '[B][COLOR FF28A895]• Series 1080p[/COLOR][/B]', 'mode': 'list_series', 'type': 'series_1080p'},
        {'title': '[B][COLOR lime]• Series 720p[/COLOR][/B]', 'mode': 'list_series', 'type': 'series_720p'},
        {'title': '[B][COLOR FF28A895]• Series 480p[/COLOR][/B]', 'mode': 'list_series', 'type': 'series_480p'},
        {'title': '[B][COLOR violet]• Buscar Película o Serie[/COLOR][/B]', 'mode': 'search'},
    ]

    for item in items:
        li = xbmcgui.ListItem(label=item['title'])
        li.setArt({'thumb': 'DefaultMovies.png', 'icon': 'DefaultMovies.png', 'fanart': fanart_path})
        li.setInfo('video', {'title': item['title']})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            build_url({'mode': item['mode'], 'type': item.get('type'), 'page': '1'}),
            li,
            True
        )

    li = xbmcgui.ListItem(label='[B][COLOR FFFF9E80]• Últimos Torrents Reproducidos[/COLOR][/B]')
    li.setArt({
        'thumb': 'DefaultMovies.png', 
        'icon': 'DefaultMovies.png',
        'fanart': fanart_path
    })
    li.setInfo('video', {'title': 'Últimos Torrents Reproducidos'})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url='plugin://plugin.program.autowidget/?mode=path&group=jacktook-1756460733.1426642&path_id=torrents_recientes-1768557289.5216126&refresh=&reload=&sf_options=winID%3D10025%26meta%3Dvotes%253D0%2526label%253DTorrents%252Bvistos%252Brecientemente%26_options_sf',
        listitem=li,
        isFolder=True
    )

    li = xbmcgui.ListItem(label='[B][COLOR FF90A4AE]• Limpiar caché de categorías[/COLOR][/B]')
    li.setArt({'thumb': 'DefaultMovies.png', 'icon': 'DefaultMovies.png', 'fanart': fanart_path})
    xbmcplugin.addDirectoryItem(addon_handle, build_url({'mode': 'clear_cache'}), li, False)

    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)

def list_movies(content_type, page):
    scraper = get_scraper()
    tmdb = get_tmdb()
    url = BASE_URLS.get(content_type)
    if not url:
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)
        return

    movies = scraper.get_movies(url, int(page))
    items = []
    for movie in movies:
        title = movie.get('clean_title', movie.get('title', ''))
        year = movie.get('year', '')
        if not title: 
            continue
        display_title = clean_display_title(title, year)
        tmdb_info = tmdb.search_movie(title, year) if title and year else None
        tmdb_id = str(tmdb_info.get('id', '')) if tmdb_info else ''
        play_url = build_url({'mode': 'select_movie_source', 'title': display_title, 'year': year, 'tmdb_id': tmdb_id, 'media_type': 'movie'})
        label = f"{display_title} ({year})" if year and f"({year})" not in display_title else display_title
        li = xbmcgui.ListItem(label=label)
        li.setProperty('IsPlayable', 'false')
        info = {'title': display_title, 'originaltitle': title, 'mediatype': 'movie'}
        if year and year.isdigit():
            info['year'] = int(year)
        if tmdb_info:
            info.update({
                'plot': tmdb_info.get('overview', ''),
                'rating': float(tmdb_info.get('vote_average') or 0),
                'genre': ' / '.join(tmdb_info.get('genres', [])),
                'duration': tmdb_info.get('runtime', 0),
                'mpaa': tmdb_info.get('certification', '')
            })
        li.setInfo('video', info)
        if tmdb_info and tmdb_info.get('poster_path'):
            poster = f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}"
            li.setArt({'thumb': poster, 'poster': poster})
        else:
            li.setArt({'thumb': 'DefaultMovies.png', 'poster': 'DefaultMovies.png'})
        if tmdb_info and tmdb_info.get('backdrop_path'):
            li.setArt({'fanart': f"https://image.tmdb.org/t/p/w1280{tmdb_info['backdrop_path']}"})
        items.append((play_url, li, True))

    for url, li, is_folder in items:
        xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=is_folder)

    if movies:
        next_page = str(int(page) + 1)
        li = xbmcgui.ListItem(label=f"[COLOR gold]Página {next_page} >>>[/COLOR]")
        xbmcplugin.addDirectoryItem(addon_handle, build_url({'mode': 'list_movies', 'type': content_type, 'page': next_page}), li, True)

    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)

def list_series(content_type, page):
    scraper = get_scraper()
    tmdb = get_tmdb()
    url = BASE_URLS.get(content_type)
    if not url:
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)
        return

    series_list = scraper.get_series(url, int(page))
    items = []
    for series in series_list:
        title = series.get('clean_title', series.get('title', ''))
        year = series.get('year', '')
        if not title: 
            continue
        display_title = clean_display_title(title, year)
        tmdb_info = tmdb.search_tv(display_title, year) if display_title else None
        tmdb_id = str(tmdb_info.get('id', '')) if tmdb_info else ''
        play_url = build_url({'mode': 'select_series_season', 'title': display_title, 'year': year, 'tmdb_id': tmdb_id, 'media_type': 'tv'})
        label = f"{display_title} ({year})" if year and f"({year})" not in display_title else display_title
        li = xbmcgui.ListItem(label=label)
        li.setProperty('IsPlayable', 'false')
        info = {'title': display_title, 'mediatype': 'tvshow'}
        if year and year.isdigit():
            info['year'] = int(year)
        if tmdb_info:
            info.update({
                'plot': tmdb_info.get('overview', ''),
                'rating': float(tmdb_info.get('vote_average') or 0),
                'genre': ' / '.join(tmdb_info.get('genres', [])),
                'mpaa': tmdb_info.get('certification', '')
            })
        li.setInfo('video', info)
        if tmdb_info and tmdb_info.get('poster_path'):
            poster = f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}"
            li.setArt({'thumb': poster, 'poster': poster})
        else:
            li.setArt({'thumb': 'DefaultTVShows.png', 'poster': 'DefaultTVShows.png'})
        if tmdb_info and tmdb_info.get('backdrop_path'):
            li.setArt({'fanart': f"https://image.tmdb.org/t/p/w1280{tmdb_info['backdrop_path']}"})
        items.append((play_url, li, True))

    for url, li, is_folder in items:
        xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=is_folder)

    if series_list:
        next_page = str(int(page) + 1)
        li = xbmcgui.ListItem(label=f"[COLOR yellow]Página {next_page} >>>[/COLOR]")
        xbmcplugin.addDirectoryItem(addon_handle, build_url({'mode': 'list_series', 'type': content_type, 'page': next_page}), li, True)

    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)

def search():
    keyboard = xbmc.Keyboard('', 'Buscar película o serie')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)
        return
    query = keyboard.getText().strip()
    if len(query) < 2:
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)
        return
    tmdb = get_tmdb()
    results = tmdb.multi_search(query)
    items = []
    for result in results:
        media_type = result.get('media_type')
        title = result.get('title') or result.get('name', '')
        year = (result.get('release_date') or result.get('first_air_date', '') or '')[:4]
        if not title: 
            continue
        if media_type == 'movie':
            tmdb_id = str(result.get('id', ''))
            label = f"[B][PELICULA:][/B] {title} ({year})" if year else f"[B][PELICULA:][/B] {title}"
            url = build_url({'mode': 'select_movie_source', 'title': title, 'year': year, 'tmdb_id': tmdb_id, 'media_type': 'movie'})
            mediatype = 'movie'
        elif media_type == 'tv':
            tmdb_id = str(result.get('id', ''))
            label = f"[B][SERIE:][/B] {title} ({year})" if year else f"[B][SERIE:][/B] {title}"
            url = build_url({'mode': 'select_series_season', 'title': title, 'year': year, 'tmdb_id': tmdb_id, 'media_type': 'tv'})
            mediatype = 'tvshow'
        else:
            continue
        li = xbmcgui.ListItem(label=label)
        li.setProperty('IsPlayable', 'false')
        info = {'title': title, 'plot': result.get('overview', ''), 'mediatype': mediatype}
        if year and year.isdigit():
            info['year'] = int(year)
        li.setInfo('video', info)
        if result.get('poster_path'):
            poster = f"https://image.tmdb.org/t/p/w500{result['poster_path']}"
            li.setArt({'thumb': poster, 'poster': poster})
        if result.get('backdrop_path'):
            li.setArt({'fanart': f"https://image.tmdb.org/t/p/w1280{result['backdrop_path']}"})
        items.append((url, li, True))
    for url, li, is_folder in items:
        xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=is_folder)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)

def select_movie_source(title, year, tmdb_id):
    play_movie(title, year, tmdb_id)

def select_series_season(title, year, tmdb_id):
    if not tmdb_id or not tmdb_id.isdigit():
        xbmcgui.Dialog().ok('Error', 'No se encontró información de TMDB.')
        return
    dialog = SeasonEpisodeDialog()
    season_info = dialog.select_season(tmdb_id, title)
    if not season_info:
        return
    select_series_episode(title, year, tmdb_id, season_info['season_number'])

def select_series_episode(title, year, tmdb_id, season_number):
    if not tmdb_id or not tmdb_id.isdigit():
        xbmcgui.Dialog().ok('Error', 'No se encontró información de TMDB.')
        return
    dialog = SeasonEpisodeDialog()
    episode_info = dialog.select_episode(tmdb_id, title, season_number)
    if not episode_info:
        return
    play_series_episode(title, year, tmdb_id, season_number, episode_info['episode_number'], episode_info.get('episode_title'))

def play_movie(title, year, tmdb_id):
    player = get_player()
    play_url = player.get_movie_play_url(title=title)
    li = xbmcgui.ListItem(label=title)
    li.setProperty('IsPlayable', 'true')
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    xbmc.Player().play(play_url, li)

def play_series_episode(title, year, tmdb_id, season, episode, episode_title=None):
    if not episode_title:
        episode_title = title
    player = get_player()
    play_url = player.get_series_play_url(
        showname=title,
        season=season,
        episode=episode,
        episode_title=episode_title
    )
    label = f"{title} S{season:02d}E{episode:02d}"
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    li.setInfo('video', {'title': label, 'mediatype': 'episode'})
    xbmc.Player().play(play_url, li)

def clear_cache():
    cache_manager = get_cache_manager()
    cleared = cache_manager.clear_all_cache()
    if cleared > 0:
        xbmcgui.Dialog().ok('Caché limpiado', f'Se han eliminado {cleared} archivos de caché.')
    else:
        xbmcgui.Dialog().ok('Caché', 'No había archivos de caché para limpiar.')
    xbmc.executebuiltin('Container.Refresh')

def router():
    params = urllib.parse.parse_qs(sys.argv[2][1:].lstrip('?'))
    mode = params.get('mode', ['main'])[0]
    global addon_handle, base_url
    addon_handle = int(sys.argv[1])
    base_url = sys.argv[0]
    get_proxy_manager().load_proxy_settings()
    actions = {
        'main': main_menu,
        'list_movies': lambda: list_movies(params.get('type', ['movies_4k'])[0], params.get('page', ['1'])[0]),
        'list_series': lambda: list_series(params.get('type', ['series_4k'])[0], params.get('page', ['1'])[0]),
        'search': search,
        'select_movie_source': lambda: select_movie_source(params.get('title', [''])[0], params.get('year', [''])[0], params.get('tmdb_id', [''])[0]),
        'select_series_season': lambda: select_series_season(params.get('title', [''])[0], params.get('year', [''])[0], params.get('tmdb_id', [''])[0]),
        'test_connection': lambda: xbmcgui.Dialog().ok('Test de conexión', test_wolfmax_connection()[1]),
        'proxy_settings': lambda: (get_proxy_manager().configure_proxy_settings(), xbmc.executebuiltin('Container.Refresh')),
        'clear_cache': clear_cache,
        'noop': lambda: None,
    }
    actions.get(mode, main_menu)()

if __name__ == '__main__':
    router()