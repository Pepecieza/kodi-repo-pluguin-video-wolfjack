import xbmc
import xbmcaddon
import time

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
_log_cache = {}

def log(message, level=xbmc.LOGDEBUG):
    current_time = time.time()
    cache_key = f"{message}_{level}"
    
    if cache_key in _log_cache:
        if current_time - _log_cache[cache_key] < 2:
            return
    _log_cache[cache_key] = current_time
    
    if len(_log_cache) > 100:
        _log_cache.clear()
    
    xbmc.log(f"[{addon_name}] {message}", level)