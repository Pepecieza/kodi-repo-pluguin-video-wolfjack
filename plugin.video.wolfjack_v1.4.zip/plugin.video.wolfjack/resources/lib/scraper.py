import requests
from bs4 import BeautifulSoup
import re
import datetime
from utils import log
import xbmcvfs
import os
import json
import time
import xbmcaddon
from disk_cache import DiskCacheManager

class WolfmaxScraper:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.proxy_enabled = self.addon.getSetting('proxy_enabled') == 'true'
        self.proxy_address = self.addon.getSetting('proxy_address')
        
        # Inicializar gestor de caché en disco
        self.disk_cache = DiskCacheManager()
        
        # Configurar sesión con o sin proxy SOLO para wolfmax4k.com
        self.wolfmax_session = self._create_wolfmax_session()
        
        # Configurar sesión DIRECTA (sin proxy) para TMDB y otros
        self.direct_session = requests.Session()
        self.direct_session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Encoding': 'gzip, deflate',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'es-ES,es;q=0.9',
        })
        
        self.current_year = str(datetime.datetime.now().year)
        
        # Precompilar regex
        self.title_clean_regex = [
            re.compile(r'\[.*?\]'),
            re.compile(r'\b\w+\]'),
            re.compile(r'\[|\]'),
            re.compile(r'\s+')
        ]
        self.quality_regex = re.compile(r'\s+(4K|2160p|HDR|UHD|DUAL|ESP|LAT|SUB|AC3|5\.1|1080p|720p|480p|Bluray|WEB).*$', re.IGNORECASE)
        self.year_regex = re.compile(r'\b(19\d{2}|20[0-3]\d)\b')
    
    def _create_wolfmax_session(self):
        """Crear sesión específica para wolfmax4k.com (con o sin proxy)"""
        session = requests.Session()
        
        if self.proxy_enabled and self.proxy_address:
            session.proxies = {
                'http': f'http://{self.proxy_address}',
                'https': f'http://{self.proxy_address}'
            }
            log(f"Scraper usando proxy: {self.proxy_address} para wolfmax4k.com")
        else:
            log("Scraper usando conexión DIRECTA para wolfmax4k.com")
        
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Encoding': 'gzip, deflate',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'es-ES,es;q=0.9',
            'Referer': 'https://wolfmax4k.com/',
        })
        
        return session

    def get_all_items_from_url(self, url, is_tv=False):
        """Descargar TODOS los items de wolfmax4k.com usando la sesión específica"""
        try:
            all_items = []
            
            # Wolfmax4k muestra máximo 100 elementos en 5 páginas de 20
            for page_num in range(1, 6):
                page_url = f"{url.rstrip('/')}/page/{page_num}/" if page_num > 1 else url
                
                response = self.wolfmax_session.get(page_url, timeout=15)
                if response.status_code != 200:
                    log(f"Error al acceder a {page_url}: Status {response.status_code}")
                    break
                
                soup = BeautifulSoup(response.text, 'html.parser')
                cards = soup.find_all('a', class_='card card-movie')
                
                if not cards:
                    break
                
                for card in cards:
                    title_elem = card.find('h3', class_='title')
                    title = title_elem.get_text(strip=True) if title_elem else ''
                    
                    if not title:
                        continue
                    
                    img = card.find('img', class_='img-fluid rounded-1')
                    thumb = img['src'] if img else ''
                    
                    quality = card.find('div', class_='quality')
                    qual_text = quality.get_text(strip=True) if quality else ''
                    
                    fdi_type = card.find('span', class_='fdi-type')
                    year_site = fdi_type.get_text(strip=True) if fdi_type else ''
                    
                    item = {
                        'title': title,
                        'year': year_site,
                        'url': card['href'],
                        'thumb': thumb,
                        'quality': qual_text
                    }
                    
                    # Procesar item
                    processed_item = self.process_item(item, is_tv)
                    all_items.append(processed_item)
                
                log(f"Página {page_num}: {len(cards)} items")
                
                # Si hay menos de 20 items, es la última página
                if len(cards) < 20:
                    break
            
            return all_items
            
        except Exception as e:
            log(f"Error descargando items desde wolfmax4k.com: {str(e)}")
            return []

    def extract_year_and_clean_title(self, title, is_tv=False):
        """Extraer año y limpiar título"""
        if not title:
            return title, None
        
        original = title.strip()
        cleaned = original
        
        for regex in self.title_clean_regex[:3]:
            cleaned = regex.sub(' ', cleaned)
        
        years = self.year_regex.findall(cleaned)
        year = years[-1] if years else None
        
        cleaned = self.quality_regex.sub('', cleaned)
        
        if year:
            year_pattern = re.compile(rf'\s*[\(\[]?\s*{year}\s*[\)\]]?\s*$')
            cleaned = year_pattern.sub('', cleaned)
        
        cleaned = self.title_clean_regex[3].sub(' ', cleaned).strip()
        
        return cleaned if cleaned else original, year

    def process_item(self, item, is_tv=False):
        title = item['title']
        year_site = item['year']
        
        clean, year_title = self.extract_year_and_clean_title(title, is_tv)
        
        final_year = year_title if year_title else year_site
        
        if final_year == self.current_year and not year_title:
            year_match = re.search(r'\((\d{4})\)', title)
            if year_match:
                final_year = year_match.group(1)
        
        item['clean_title'] = clean
        item['search_title'] = title.strip()
        item['year'] = final_year
        
        return item

    def get_movies(self, url, page=1):
        """Obtener películas con paginación simulada desde caché de disco"""
        # Identificar categoría desde la URL
        category_name = None
        from default import BASE_URLS
        for key, value in BASE_URLS.items():
            if value == url:
                category_name = key
                break
        
        if not category_name:
            category_name = f"movies_{hash(url) % 10000}"
        
        # Intentar cargar desde caché de disco
        cached_items = self.disk_cache.load_category_from_disk(category_name)
        
        # Si no hay caché o está expirado, descargar y guardar
        if cached_items is None:
            log(f"Descargando categoría: {category_name}")
            all_items = self.get_all_items_from_url(url, is_tv=False)
            if all_items:
                self.disk_cache.save_category_to_disk(category_name, all_items)
            else:
                return []
        else:
            all_items = cached_items
        
        # Paginación simulada: 20 items por página
        page = int(page)
        start_idx = (page - 1) * 20
        end_idx = start_idx + 20
        
        return all_items[start_idx:end_idx]

    def get_series(self, url, page=1):
        """Obtener series con paginación simulada desde caché de disco"""
        # Identificar categoría desde la URL
        category_name = None
        from default import BASE_URLS
        for key, value in BASE_URLS.items():
            if value == url:
                category_name = key
                break
        
        if not category_name:
            category_name = f"series_{hash(url) % 10000}"
        
        # Intentar cargar desde caché de disco
        cached_items = self.disk_cache.load_category_from_disk(category_name)
        
        # Si no hay caché o está expirado, descargar y guardar
        if cached_items is None:
            log(f"Descargando categoría: {category_name}")
            all_items = self.get_all_items_from_url(url, is_tv=True)
            if all_items:
                self.disk_cache.save_category_to_disk(category_name, all_items)
            else:
                return []
        else:
            all_items = cached_items
        
        # Eliminar duplicados por título limpio
        seen = set()
        unique_items = []
        for item in all_items:
            key = item['clean_title'].lower().strip()
            if key not in seen:
                seen.add(key)
                unique_items.append(item)
        
        # Paginación simulada: 20 items por página
        page = int(page)
        start_idx = (page - 1) * 20
        end_idx = start_idx + 20
        
        return unique_items[start_idx:end_idx]