import xbmcvfs
import os
import json
import time
import hashlib
from utils import log

class DiskCacheManager:
    def __init__(self, addon_id="plugin.video.wolfjack"):
        self.addon_id = addon_id
        self.cache_dir = xbmcvfs.translatePath(f"special://userdata/addon_data/{addon_id}/cache/")
        self.cache_duration = 1800  # 30 minutos
        
        if not xbmcvfs.exists(self.cache_dir):
            xbmcvfs.mkdirs(self.cache_dir)
    
    def get_cache_file_path(self, category):
        """Obtener ruta del archivo de caché para una categoría"""
        safe_category = "".join(c for c in category if c.isalnum() or c in ('_', '-')).rstrip()
        return os.path.join(self.cache_dir, f"{safe_category}.json")
    
    def save_category_to_disk(self, category, items):
        """Guardar todos los items de una categoría en disco"""
        try:
            cache_file = self.get_cache_file_path(category)
            
            cache_data = {
                'timestamp': time.time(),
                'category': category,
                'total_items': len(items),
                'items': items
            }
            
            with xbmcvfs.File(cache_file, 'w') as f:
                f.write(json.dumps(cache_data, ensure_ascii=False))
            
            log(f"Caché guardado en disco: {category} - {len(items)} items")
            return True
            
        except Exception as e:
            log(f"Error guardando caché en disco: {str(e)}")
            return False
    
    def load_category_from_disk(self, category):
        """Cargar todos los items de una categoría desde disco"""
        try:
            cache_file = self.get_cache_file_path(category)
            
            if not xbmcvfs.exists(cache_file):
                return None
            
            with xbmcvfs.File(cache_file, 'r') as f:
                cache_data = json.loads(f.read())
            
            # Verificar si el caché ha expirado
            current_time = time.time()
            cache_age = current_time - cache_data.get('timestamp', 0)
            
            if cache_age < self.cache_duration:
                log(f"Caché cargado desde disco: {category} - {len(cache_data.get('items', []))} items")
                return cache_data.get('items', [])
            else:
                log(f"Caché expirado: {category} (edad: {int(cache_age)}s)")
                return None
                
        except Exception as e:
            log(f"Error cargando caché desde disco: {str(e)}")
            return None
    
    def get_paginated_items(self, category, page=1, items_per_page=20):
        """Obtener items paginados de una categoría"""
        all_items = self.load_category_from_disk(category)
        if all_items is None:
            return []
        
        page = int(page)
        start_idx = (page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        
        return all_items[start_idx:end_idx]
    
    def clear_category_cache(self, category):
        """Limpiar caché de una categoría específica"""
        try:
            cache_file = self.get_cache_file_path(category)
            if xbmcvfs.exists(cache_file):
                xbmcvfs.delete(cache_file)
                log(f"Caché eliminado: {category}")
                return True
            return False
        except Exception as e:
            log(f"Error eliminando caché: {str(e)}")
            return False
    
    def clear_all_cache(self):
        """Limpiar todo el caché"""
        try:
            if xbmcvfs.exists(self.cache_dir):
                files = xbmcvfs.listdir(self.cache_dir)[1]
                deleted = 0
                for file in files:
                    if file.endswith('.json'):
                        xbmcvfs.delete(os.path.join(self.cache_dir, file))
                        deleted += 1
                log(f"Todo el caché limpiado: {deleted} archivos")
                return deleted
            return 0
        except Exception as e:
            log(f"Error limpiando todo el caché: {str(e)}")
            return 0