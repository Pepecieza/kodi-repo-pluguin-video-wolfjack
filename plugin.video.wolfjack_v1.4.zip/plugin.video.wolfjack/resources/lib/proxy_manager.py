import xbmc
import xbmcgui
import xbmcaddon
import requests
import re
import random
import time
import os
import sys
import socket
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from utils import log

class ProxyManager:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.proxy_sources = [
            'mmpx12',
            'proxyscrape.com',
            'us-proxy.org',
            'free-proxy-list.anon',
            'free-proxy-list',
            'sslproxies.org',
            'spys.one',
            'hidemy.name',
            'google-proxy.net'
        ]
        self.current_proxy = None
        self.test_url = 'https://wolfmax4k.com/'
        self.proxy_timeout = 8
        self.max_proxies_to_test = 50
        self.ping_timeout = 3
        self.working_proxies_cache = []
        self.last_proxy_search_time = 0
        self.cache_duration = 3600
        
    def ping_proxy(self, proxy):
        """Realizar ping TCP al proxy para medir latencia"""
        try:
            if ':' not in proxy:
                return None, 9999
            
            ip, port_str = proxy.split(':', 1)
            port = int(port_str)
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.ping_timeout)
            
            start_time = time.time()
            sock.connect((ip, port))
            connection_time = time.time() - start_time
            sock.close()
            
            return proxy, connection_time
            
        except socket.timeout:
            return proxy, 9999
        except ConnectionRefusedError:
            return proxy, 9999
        except Exception as e:
            log(f"Error en ping a {proxy}: {str(e)}")
            return proxy, 9999
    
    def test_proxy_full(self, proxy, url):
        """Testear completamente si un proxy funciona con wolfmax4k.com"""
        try:
            proxies = {
                'http': f'http://{proxy}',
                'https': f'http://{proxy}'
            }
            
            start_time = time.time()
            response = requests.get(
                url, 
                proxies=proxies, 
                timeout=self.proxy_timeout,
                headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'es-ES,es;q=0.9',
                }
            )
            
            total_time = time.time() - start_time
            
            if response.status_code == 200 and 'wolfmax4k' in response.text.lower():
                content_length = len(response.content)
                speed = content_length / total_time if total_time > 0 else 0
                return True, total_time, speed
            else:
                return False, total_time, 0
                
        except Exception as e:
            return False, self.proxy_timeout, 0
    
    def fetch_proxies(self, source_name):
        """Obtener proxies de diferentes fuentes"""
        proxies = []
        
        try:
            if source_name == 'mmpx12':
                url = 'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt'
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    proxies = response.text.strip().split('\n')
                    
            elif source_name == 'proxyscrape.com':
                url = 'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http'
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    proxies = response.text.strip().split('\n')
                    
            elif source_name == 'us-proxy.org':
                url = 'https://www.us-proxy.org/'
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    matches = re.findall(r'(\d+\.\d+\.\d+\.\d+:\d+)', response.text)
                    proxies = matches[:100]
                    
            elif source_name == 'free-proxy-list.anon':
                url = 'https://free-proxy-list.net/anonymous-proxy.html'
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    matches = re.findall(r'(\d+\.\d+\.\d+\.\d+:\d+)', response.text)
                    proxies = matches[:100]
                    
            elif source_name == 'free-proxy-list':
                url = 'https://free-proxy-list.net/'
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    matches = re.findall(r'(\d+\.\d+\.\d+\.\d+:\d+)', response.text)
                    proxies = matches[:100]
                    
            elif source_name == 'sslproxies.org':
                url = 'https://www.sslproxies.org/'
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    matches = re.findall(r'(\d+\.\d+\.\d+\.\d+:\d+)', response.text)
                    proxies = matches[:100]
                    
            elif source_name == 'spys.one':
                url = 'https://spys.one/en/free-proxy-list/'
                response = requests.get(url, timeout=15)
                if response.status_code == 200:
                    matches = re.findall(r'(\d+\.\d+\.\d+\.\d+:\d+)', response.text)
                    proxies = matches[:100]
                    
            elif source_name == 'hidemy.name':
                url = 'https://hidemy.io/es/proxy-list/'
                response = requests.get(url, timeout=15)
                if response.status_code == 200:
                    matches = re.findall(r'(\d+\.\d+\.\d+\.\d+:\d+)', response.text)
                    proxies = matches[:100]
                    
            elif source_name == 'google-proxy.net':
                url = 'https://www.google-proxy.net/'
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    matches = re.findall(r'(\d+\.\d+\.\d+\.\d+:\d+)', response.text)
                    proxies = matches[:100]
            
            clean_proxies = []
            for proxy in proxies:
                proxy = proxy.strip()
                if re.match(r'^\d+\.\d+\.\d+\.\d+:\d+$', proxy):
                    clean_proxies.append(proxy)
            
            return clean_proxies[:50]
            
        except Exception as e:
            log(f"Error fetching proxies from {source_name}: {str(e)}")
            return []
    
    def find_working_proxy(self, force_search=False):
        """Buscar un proxy que funcione con wolfmax4k.com"""
        current_time = time.time()
        if (not force_search and self.working_proxies_cache and 
            current_time - self.last_proxy_search_time < self.cache_duration):
            if self.working_proxies_cache:
                fastest_proxy = min(self.working_proxies_cache, key=lambda x: x[1])[0]
                self.current_proxy = fastest_proxy
                return fastest_proxy
        
        dialog = xbmcgui.DialogProgress()
        dialog.create('WolfJack - Buscando Proxy', 'Buscando proxy más rápido para wolfmax4k.com...')
        
        all_proxies = []
        
        for i, source in enumerate(self.proxy_sources):
            if dialog.iscanceled():
                break
                
            dialog.update(int((i / len(self.proxy_sources)) * 20), 
                         f'Obteniendo proxies de {source}...')
            
            proxies = self.fetch_proxies(source)
            all_proxies.extend(proxies)
            
            time.sleep(0.3)
        
        all_proxies = list(set(all_proxies))
        
        if not all_proxies:
            dialog.close()
            return None
        
        # Paso 1: Realizar ping a todos los proxies
        dialog.update(20, f'Realizando ping a {len(all_proxies)} proxies...')
        
        ping_results = []
        with ThreadPoolExecutor(max_workers=20) as executor:
            future_to_proxy = {executor.submit(self.ping_proxy, proxy): proxy for proxy in all_proxies}
            
            for i, future in enumerate(as_completed(future_to_proxy)):
                if dialog.iscanceled():
                    break
                    
                proxy, ping_time = future.result()
                if ping_time < 9999:
                    ping_results.append((proxy, ping_time))
                
                progress = 20 + int((i / len(future_to_proxy)) * 20)
                dialog.update(progress, f'Ping completado: {i+1}/{len(future_to_proxy)}')
        
        ping_results.sort(key=lambda x: x[1])
        
        if not ping_results:
            dialog.close()
            xbmcgui.Dialog().ok(
                'WolfJack - Sin proxies',
                'No se encontraron proxies que respondan al ping.',
                'Todos los proxies están offline o bloqueados.'
            )
            return None
        
        # Paso 2: Testear los 20 proxies con mejor ping
        dialog.update(40, f'Testeando los {min(20, len(ping_results))} proxies más rápidos...')
        
        working_proxies = []
        proxies_to_test = [proxy for proxy, _ in ping_results[:20]]
        
        with ThreadPoolExecutor(max_workers=10) as executor:
            future_to_proxy = {executor.submit(self.test_proxy_full, proxy, self.test_url): proxy 
                              for proxy in proxies_to_test}
            
            for i, future in enumerate(as_completed(future_to_proxy)):
                if dialog.iscanceled():
                    break
                    
                proxy = future_to_proxy[future]
                works, response_time, speed = future.result()
                
                if works:
                    proxy_ping = next((ping for p, ping in ping_results if p == proxy), 1.0)
                    score = (proxy_ping * 0.5) + (response_time * 0.5)
                    
                    working_proxies.append((proxy, score, response_time, speed))
                
                progress = 40 + int((i / len(future_to_proxy)) * 40)
                dialog.update(progress, f'Testeando proxy {i+1}/{len(future_to_proxy)}: {proxy}')
        
        dialog.close()
        
        if working_proxies:
            working_proxies.sort(key=lambda x: x[1])
            
            self.working_proxies_cache = working_proxies
            self.last_proxy_search_time = current_time
            
            fastest_proxy = working_proxies[0][0]
            response_time = working_proxies[0][2]
            speed = working_proxies[0][3]
            
            self.current_proxy = fastest_proxy
            
            speed_kbps = speed / 1024
            xbmcgui.Dialog().notification(
                'Proxy más rápido encontrado',
                f'{fastest_proxy}\nTiempo: {response_time:.2f}s | Vel: {speed_kbps:.1f} KB/s',
                xbmcgui.NOTIFICATION_INFO,
                5000
            )
            
            log(f"Proxy más rápido seleccionado: {fastest_proxy} | Tiempo respuesta: {response_time:.2f}s | Velocidad: {speed_kbps:.1f} KB/s")
            
            return fastest_proxy
        else:
            xbmcgui.Dialog().ok(
                'WolfJack - Sin proxies funcionales',
                'No se encontraron proxies funcionales para wolfmax4k.com.',
                'Los proxies encontrados no pueden acceder al sitio.',
                'Recomendación: Usar VPN o intentar más tarde.'
            )
            return None
    
    def get_session_for_wolfmax(self):
        """Obtener una sesión requests CON proxy para wolfmax4k.com"""
        session = requests.Session()
        
        if self.current_proxy:
            session.proxies = {
                'http': f'http://{self.current_proxy}',
                'https': f'http://{self.current_proxy}'
            }
        
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Encoding': 'gzip, deflate',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'es-ES,es;q=0.9',
            'Referer': 'https://wolfmax4k.com/',
        })
        
        return session
    
    def get_direct_session(self):
        """Obtener una sesión requests SIN proxy (conexión directa)"""
        session = requests.Session()
        
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Encoding': 'gzip, deflate',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'es-ES,es;q=0.9',
        })
        
        return session
    
    def configure_proxy_settings(self):
        """Mostrar diálogo de configuración de proxy"""
        options = [
            'Buscar proxy automáticamente (encontrar el más rápido)',
            'Configurar proxy manualmente',
            'Desactivar proxy',
            'Testear proxy actual',
            'Ver estadísticas de proxies'
        ]
        
        if self.current_proxy:
            options.insert(0, f'Proxy actual: {self.current_proxy}')
        
        ret = xbmcgui.Dialog().select('Configuración de Proxy', options)
        
        if ret == -1:
            return
        
        if self.current_proxy and ret == 0:
            ret = xbmcgui.Dialog().select('Configuración de Proxy', options[1:])
            if ret == -1:
                return
            ret += 1
        
        if (self.current_proxy and ret == 1) or (not self.current_proxy and ret == 0):
            # Buscar proxy automáticamente
            proxy = self.find_working_proxy(force_search=True)
            if proxy:
                self.save_proxy_settings(proxy)
                
        elif (self.current_proxy and ret == 2) or (not self.current_proxy and ret == 1):
            # Configurar proxy manualmente
            proxy = xbmcgui.Dialog().input(
                'Ingresa proxy (formato: IP:Puerto)',
                defaultt=self.current_proxy if self.current_proxy else ''
            )
            if proxy:
                if self.validate_proxy_format(proxy):
                    works, response_time, speed = self.test_proxy_full(proxy, self.test_url)
                    if works:
                        self.current_proxy = proxy
                        self.save_proxy_settings(proxy)
                        speed_kbps = speed / 1024
                        xbmcgui.Dialog().ok(
                            'Proxy configurado', 
                            f'Proxy {proxy} configurado correctamente.\n\n' +
                            f'• Tiempo de respuesta: {response_time:.2f} segundos\n' +
                            f'• Velocidad: {speed_kbps:.1f} KB/s'
                        )
                    else:
                        xbmcgui.Dialog().ok('X Error', 'El proxy no funciona con wolfmax4k.com.')
                else:
                    xbmcgui.Dialog().ok('X Error', 'Formato de proxy inválido. Usa IP:Puerto')
                    
        elif (self.current_proxy and ret == 3) or (not self.current_proxy and ret == 2):
            # Desactivar proxy
            self.current_proxy = None
            self.working_proxies_cache = []
            self.save_proxy_settings('')
            xbmcgui.Dialog().notification(
                'Proxy desactivado',
                'Proxy desactivado correctamente',
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
            
        elif (self.current_proxy and ret == 4) or (not self.current_proxy and ret == 3):
            # Testear proxy actual
            if self.current_proxy:
                works, response_time, speed = self.test_proxy_full(self.current_proxy, self.test_url)
                if works:
                    speed_kbps = speed / 1024
                    xbmcgui.Dialog().ok(
                        'Proxy funcional',
                        f'Proxy {self.current_proxy} funciona correctamente.\n\n' +
                        f'• Tiempo de respuesta: {response_time:.2f} segundos\n' +
                        f'• Velocidad: {speed_kbps:.1f} KB/s\n' +
                        f'• Estado: Óptimo'
                    )
                else:
                    xbmcgui.Dialog().ok('❌ Proxy no funcional', 'El proxy actual no funciona.\nRecomendado: Buscar nuevo proxy automáticamente.')
            else:
                xbmcgui.Dialog().ok('Sin proxy', 'No hay proxy configurado actualmente.')
                
        elif (self.current_proxy and ret == 5) or (not self.current_proxy and ret == 4):
            # Ver estadísticas de proxies
            if self.working_proxies_cache:
                stats_text = 'Proxies más rápidos encontrados:\n\n'
                for i, (proxy, score, response_time, speed) in enumerate(self.working_proxies_cache[:10]):
                    speed_kbps = speed / 1024
                    stats_text += f'{i+1}. {proxy}\n'
                    stats_text += f'   {response_time:.2f}s | {speed_kbps:.1f} KB/s\n\n'
                
                stats_text += f'Cache actualizado hace: {int(time.time() - self.last_proxy_search_time)} segundos'
                xbmcgui.Dialog().textviewer('Estadísticas de Proxies', stats_text)
            else:
                xbmcgui.Dialog().ok('Sin estadísticas', 'No hay estadísticas de proxies disponibles.\nBusca proxies primero para generar estadísticas.')
    
    def validate_proxy_format(self, proxy):
        """Validar formato del proxy"""
        return re.match(r'^\d+\.\d+\.\d+\.\d+:\d+$', proxy) is not None
    
    def save_proxy_settings(self, proxy):
        """Guardar configuración del proxy"""
        self.addon.setSetting('proxy_enabled', 'true' if proxy else 'false')
        self.addon.setSetting('proxy_address', proxy if proxy else '')
        self.current_proxy = proxy
        
    def load_proxy_settings(self):
        """Cargar configuración del proxy"""
        enabled = self.addon.getSetting('proxy_enabled') == 'true'
        proxy = self.addon.getSetting('proxy_address')
        
        if enabled and proxy and self.validate_proxy_format(proxy):
            self.current_proxy = proxy
            return True
        else:
            self.current_proxy = None
            return False
    
    def is_proxy_enabled(self):
        """Verificar si el proxy está habilitado"""
        return self.current_proxy is not None
    
    def get_proxy_info(self):
        """Obtener información del proxy actual"""
        if self.current_proxy:
            return {
                'enabled': True,
                'address': self.current_proxy,
                'type': 'HTTP'
            }
        else:
            return {
                'enabled': False,
                'address': '',
                'type': 'None'
            }